for tt = (1:301)

    wl = w(:,1,tt) .* L(:,1,tt) + w(:,2,tt) .* L(:,2,tt)
    rk

    GDP(:,tt) = 

end