% this function is used to solve the productivity change over time

function z_hat = productivity(w_hat, r_hat, p_hat, tau_hat, pa)







end